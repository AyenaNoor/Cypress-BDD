class Locators2 {
    navigationInTest2(){
        return cy.xpath(`//a[contains(., 'Checkboxes')]`);
        }
    
        assertNavigation() {
        return cy.url().should('include','/checkboxes')
        }
    
        uncheckSecondBox(){
        return cy.get('input').eq(1);
        }
    
        assertUnchecked(){
        return cy.get('input[type]').each((checkbox) => {
               cy.wrap(checkbox).should('not.be.checked')});
        }
    
        checkBothBoxes(){
        return cy.get('input[type]');
        }
    
        assertChecked(){
        return cy.get('input[type]').each((checkbox) => {
               cy.wrap(checkbox).should('be.checked')});
        }
}
module.exports = new Locators2;

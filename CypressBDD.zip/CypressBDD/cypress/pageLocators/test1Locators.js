require('cypress-xpath');
class Locators1 {

    navigationInTest1(){
    cy.xpath(`//a[contains(., 'Add/Remove Elements')]`).click();
    }

    assertNavigation() {
    return cy.get('h3').should('have.text','Add/Remove Elements');
    }

    clickonAddElement(){
    return cy.contains('button','Add Element');
    }

    assertElementsAdded(){
    return cy.get('#elements>button').should('have.length', 3);
    }

    clickOnDelete1(){
    return cy.contains('button','Delete');
    }

    assert1ElementDeleted(){
    return cy.contains('button','Delete').should('have.length',1);
    }
}
module.exports = new Locators1;

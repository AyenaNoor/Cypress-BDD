class Locators4 {
        navigationInTest4(){
        return cy.visit(`/dropdown`);
        }
    
        assertNavigation() {
        return cy.get('h3').should('have.text','Dropdown List');
        }

        selectOption2FromDropdown(){
        return cy.get('#dropdown').select('2');
        }
    
        assertSelection(){
        return cy.contains('Option 2').should('be.selected');
        }
}
module.exports = new Locators4;

class Locators3 {
        navigationInTest3(){
        return cy.xpath(`//a[contains(., 'Form Authentication')]`);
        }
    
        assertNavigation() {
        return cy.get('h2').should('have.text','Login Page');
        }
    
        assertError(){
        return cy.url().should('include','/login');
        }

        assertSuccessfulLogin(){
        return cy.url().should('include','/secure');
        }    
    
        clickOnLoginButton(){
        return cy.get('button');
        }
}
module.exports = new Locators3;

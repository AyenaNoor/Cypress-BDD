class Locators5 {
    navigationInTest5(){
    return cy.visit(`/dynamic_controls`);
    }

    assertNavigation() {
    return cy.get('h4').eq(0).should('have.text','Dynamic Controls');
    }

    clickOnRemove(){
    return cy.contains('button','Remove');
    }

    assertRemove(){
    return cy.get('#message').eq(0).should('include','gone!');
    }
    addButton(){
    return cy.contains('button','Add');
    }

    checkTheCheckbox(){
    cy.get('#checkbox').eq(0).check();
    }

    clickOnEnable(){
    return cy.contains('button','Enable');
    }

    assertEnable(){
    return cy.get('#input-example>input').should('be.enabled');
    }
}
module.exports = new Locators5;

const {Given, When, Then, And} = require("cypress-cucumber-preprocessor/steps");
require('cypress-real-events/support');
const Locators5 = require("../../pageLocators/test5Locators");
require('cypress-xpath');

When('I click on Dynamic Controls Element', () => {
    Locators5.navigationInTest5();
});

Then('I am navigated to dynamic controls page of herokuapp', ()=>{
    Locators5.assertNavigation();
});

When('I click on remove button', () => {
    Locators5.clickOnRemove().click();
});

When('I click on add button', () => {
    Locators5.addButton().click();
});

When('I check the checkbox',() => {
    Locators5.checkTheCheckbox();
});

When('I click on enable button',() => {
    Locators5.clickOnEnable().click();
});

Then('Input box must be enabled', ()=>{
    Locators5.assertEnable().type('It is Working!!')
});


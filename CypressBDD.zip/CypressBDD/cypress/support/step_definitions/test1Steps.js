const {Given, When, Then, And} = require("cypress-cucumber-preprocessor/steps");
require('cypress-real-events/support');
const Locators1 = require("../../pageLocators/test1Locators");
require('cypress-xpath');


When('I click on AddRemove Elements', () => {
    Locators1.navigationInTest1();
});

Then('I am navigated to addremove page of herokuapp',()=>{
    Locators1.assertNavigation();
});

When('I click on Add Element button thrice', () => {
    Locators1.clickonAddElement().click();
    Locators1.clickonAddElement().click();
    Locators1.clickonAddElement().click();
});

Then('3 delete buttons are generated', () => {
    Locators1.assertElementsAdded();
});

When('I click on delete button 1', () => {
    Locators1.clickOnDelete1().click();
});

Then('Only three delete buttons are available on the page', () => {
    Locators1.assert1ElementDeleted();
});
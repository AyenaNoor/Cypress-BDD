const {Given, When, Then, And} = require("cypress-cucumber-preprocessor/steps");
require('cypress-real-events/support');

Given('I am on the internet herokuapp site', () => {
     cy.visit('https://the-internet.herokuapp.com/');
});

And('I wait for {string} seconds', (seconds) => {
    cy.wait(seconds * 1000);
});

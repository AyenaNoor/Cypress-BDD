const {Given, When, Then, And} = require("cypress-cucumber-preprocessor/steps");
require('cypress-real-events/support');
const Locators2 = require("../../pageLocators/test2Locators");
require('cypress-xpath');


When('I click on Checkboxes Element', () => {
    Locators2.navigationInTest2().click();
});

Then('I am navigated to checkboxes page of herokuapp', ()=>{
    Locators2.assertNavigation();
});

When('I uncheck the second checkbox', () => {
    Locators2.uncheckSecondBox().uncheck();
});

Then('Both checkboxes are unchecked', () => {
    Locators2.assertUnchecked();
});

When('I check both boxes', () => {
    Locators2.checkBothBoxes().click({multiple: true});
});

Then('Both checkboxes are checked', () => {
    Locators2.assertChecked();
});
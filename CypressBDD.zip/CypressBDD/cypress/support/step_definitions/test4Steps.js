const {Given, When, Then, And} = require("cypress-cucumber-preprocessor/steps");
require('cypress-real-events/support');
const Locators4 = require("../../pageLocators/test4Locators");
require('cypress-xpath');

When('I click on Dropdown Element', () => {
    Locators4.navigationInTest4();
});

Then('I am navigated to dropdown page of herokuapp', ()=>{
    Locators4.assertNavigation();
});

When('I select option 2 from dropdown', () => {
    Locators4.selectOption2FromDropdown();
});

Then('Option 2 should be selected', () => {
    Locators4.assertSelection();
});

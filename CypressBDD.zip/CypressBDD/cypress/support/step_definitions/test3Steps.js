const {Given, When, Then, And} = require("cypress-cucumber-preprocessor/steps");
require('cypress-real-events/support');
const Locators3 = require("../../pageLocators/test3Locators");
require('cypress-xpath');


When('I click on Form Authentication Element', () => {
    Locators3.navigationInTest3().click();
});

Then('I am navigated to form authentication page of herokuapp', ()=>{
    Locators3.assertNavigation();
});

When('I enter the credentials from table', (dataTable) => {
    dataTable.hashes().forEach((row) => {
      cy.get('#username').type(row.Username);
      cy.get('#password').type(row.Password);
});
});

And('I click on login button', () => {
    Locators3.clickOnLoginButton().click();
});

Then('I should successfully log in', () => {
    Locators3.assertSuccessfulLogin();
});

Then('I should still be on the same page', () => {
    Locators3.assertError();
});